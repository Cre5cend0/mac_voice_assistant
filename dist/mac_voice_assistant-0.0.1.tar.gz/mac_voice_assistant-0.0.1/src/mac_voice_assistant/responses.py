from my_assistant import mac

mappings = {
    # 'greeting'  : mac_voice_assistant.hello,
    'set_volume': mac.set_volume,
    'set_rate'  : mac.set_rate,
    'set_name'  : mac.set_name,
    # 'calibrate' : mac_voice_assistant.calibrate,
    'speak_time': mac.speak_time,
    'tell_joke' : mac.tell_joke,
}



