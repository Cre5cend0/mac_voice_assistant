import logging

logging.basicConfig(filename="debug.log", format='%(levelname)s:%(asctime)s:%(name)s: %(message)s', level=logging.INFO)
