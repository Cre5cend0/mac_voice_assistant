import os


def call_method(obj, method):
    return obj.method()


def clearScreen():
    os.system("clear")
