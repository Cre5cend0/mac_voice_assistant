from start import initialize
from my_assistant import mac


if __name__ == '__main__':

    initialize()
    mac.begin_assisting()

